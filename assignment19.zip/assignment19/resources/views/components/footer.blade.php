<footer class="bg-white py-10 mt-0 shadow-lg px-5">
    <div class="max-w-[1200px] mx-auto px-5">
        <div class="flex-row flex items-center justify-between w-full">
            <div class="col-auto"><div class="m-0">Copyright &copy; Tamzid's Blog 2023</div></div>
            <div class="col-auto">
                <a  href="#!">Privacy</a>
                <span class="mx-1">&middot;</span>
                <a  href="#!">Terms</a>
                <span class="mx-1">&middot;</span>
                <a  href="#!">Contact</a>
            </div>
        </div>
    </div>
</footer>
