@extends('app')
@section('content')
@include('components.featured')
@endsection
